<?php
// Redirect to main registration page
header('Location: form_haji.php');
exit();
?>
